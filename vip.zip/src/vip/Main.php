<?php

namespace vip;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("vip loaded");
	}
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
   if(strtolower($command->getName()) === "vip"){
      $sender->sendMessage("§a[----------------§e[VIP]§a---------------]");
      $sender->sendMessage("§a• Aby kupić §eVIP §awyślij sms o treści §cSIM.MINTS §apod numer: §c7455");
      $sender->sendMessage("§a• §aKoszt: §c4,92 zł z vat, a otrzyman kod podaj do DawixQMC");
      $sender->sendMessage("§a• Vip jest na zawsze i otrzymujesz go na innych serwerach ");
      $sender->sendMessage("§a• Co otrzymuje §eVIP?: Komendy: /me, /kit pro, /time, /near i prywatny slot");
      $sender->sendMessage("§a• 10.000 monet, 20 diaxów, 20 szmaragdów, 20 żelaza, 20 złota,");
      $sender->sendMessage("§a• 20 złotych enchantowanych jabłek, dostęp do ukrytej wyspy");
      $sender->sendMessage("§a[----------------§e[VIP]§a---------------]");
       return true;
   }

}
}